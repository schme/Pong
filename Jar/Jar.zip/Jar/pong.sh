java -Djava.library.path="natives" -jar pong.jar
